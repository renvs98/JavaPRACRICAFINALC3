
CREATE DATABASE BDPracticaFinal
GO

USE BDPracticaFinal
GO

CREATE TABLE TBCurso(
Codigo INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
Nombre VARCHAR(55) NOT NULL
)
GO

CREATE TABLE TBProfesor(
Codigo INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
Nombre VARCHAR(55) NOT NULL,
FechaNacimiento Date,
NumCursos INT,
Sueldo DECIMAL(12,2)
)
GO


CREATE TABLE TBCursoProfesor(
CodigoProfesor INT NOT NULL,
CodigoCurso INT NOT NULL,

PRIMARY KEY(CodigoProfesor,CodigoCurso),
FOREIGN KEY(CodigoCurso) REFERENCES TBCurso(Codigo),
FOREIGN KEY(CodigoProfesor) REFERENCES TBProfesor(Codigo)
)
GO


CREATE PROCEDURE sp_asignarCursoAProfesor
@codigoCurso INT,
@codigoProfesor INT,
@msj VARCHAR(50) OUTPUT

AS
	SET NOCOUNT ON;
	BEGIN TRAN
		BEGIN TRY
			UPDATE TBProfesor SET NumCursos =NumCursos+1 WHERE Codigo = @codigoProfesor
			
			UPDATE TBProfesor SET Sueldo =(NumCursos*200) WHERE Codigo = @codigoProfesor
			
			INSERT INTO TBCursoProfesor VALUES(@codigoProfesor,@codigoCurso)
			
			
			COMMIT

			SET @msj = 'AGREGADO';
		END TRY
		BEGIN CATCH
			
			ROLLBACK
			SET @msj = 'ERROR';
		END CATCH
GO


SELECT * FROM TBCurso
SELECT * FROM TBProfesor
SELECT * FROM TBCursoProfesor